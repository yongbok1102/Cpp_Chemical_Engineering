#include <cmath>

double AntFitFunc(double a, double b, double c, double x);

double AntFitDev(double a, double b, double c, double x[], double y[], int n);
