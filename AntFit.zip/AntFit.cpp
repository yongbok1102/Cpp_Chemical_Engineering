#include <iostream>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "AntFitRoutine.h"
using namespace std;

int main(){
    ifstream is;
    is.open("samp.dat");
    if(is.bad()){
        return -1;
    }
    double X,Y;
    int N = 0;
    
    is.ignore(256,'\n');
    while(!(is.fail())){
        is>>X>>Y;
        N++;
    }
    is.close();
    is.clear();
    int n = N-1;
    double* x = new double[n];
    double* y = new double[n];
    
    is.open("samp.dat");
    is.ignore(256,'\n');
    for(int i=0; i<n; i++){
        is>>x[i]>>y[i];
    }
    /*for(int i=0; i<n; i++){
        y[i] = log10(y[i]);
    }*/
    double a, b, c;
    cout<<"Enter the initial estimation of a,b,c\n"; cin>>a>>b>>c;
    
    double aold = a + 1;
    double bold = b + 1;
    double cold = c + 1;
    
    double h;
    cout<<"Enter the spacial step for calculating derivatives\n"; cin>>h;
    
    double incr;
    cout<<"Enter the parameter for speeding up\n"; cin>>incr;
    
    double decr;
    cout<<"Enter the parameter for preventing overflowing\n"; cin>>decr;
    
    double dFda, dFdb, dFdc;
    double d2Fda2, d2Fdb2, d2Fdc2;
    double da, db, dc;
    double res = 1;
    
    double tol;
    cout<<"Enter the tolerance error\n"; cin>>tol;
    
    int itrMax;
    cout<<"Enter the maximum iteration number\n"; cin>>itrMax;
    
    double pa = 1;
    
    for(int i=1; i<=itrMax; i++){
        aold = a; bold = b; cold = c;
        dFda = AntFitDev(a+h,b,c,x,y,n) - AntFitDev(a-h,b,c,x,y,n);
        dFdb = AntFitDev(a,b+h,c,x,y,n) - AntFitDev(a,b-h,c,x,y,n);
        dFdc = AntFitDev(a,b,c+h,x,y,n) - AntFitDev(a,b,c-h,x,y,n);
        dFda /= (2.*h); dFdb /= (2.*h); dFdc /= (2.*h);
        
        d2Fda2 = AntFitDev(a+h,b,c,x,y,n) -2.*AntFitDev(a,b,c,x,y,n) + AntFitDev(a-h,b,c,x,y,n);
        d2Fdb2 = AntFitDev(a,b+h,c,x,y,n) -2.*AntFitDev(a,b,c,x,y,n) + AntFitDev(a,b-h,c,x,y,n);
        d2Fdc2 = AntFitDev(a,b,c+h,x,y,n) -2.*AntFitDev(a,b,c,x,y,n) + AntFitDev(a,b,c-h,x,y,n);
        d2Fda2 /= (h*h); d2Fdb2 /= (h*h); d2Fdc2 /= (h*h);
        
        if(fabs(d2Fda2)<=1e-08 && fabs(d2Fdb2)<=1e-08 && fabs(d2Fdc2)<=1e-08){
            da = -dFda; db = -dFdb; dc = -dFdc;
        }
        else
            da = -dFda/d2Fda2; db = -dFdb/d2Fdb2; dc = -dFdc/d2Fdc2;
        
        a = aold + pa*da; b = bold + pa*db; c = cold + pa*dc;
        if(AntFitDev(a,b,c,x,y,n)>=AntFitDev(aold,bold,cold,x,y,n)){
            pa *= decr;
            a = aold + pa*da; b = bold + pa*db; c = cold + pa*dc;
        }
        else
            pa *= incr;
        
        res = (aold-a)*(aold-a) + (bold-b)*(bold-b) + (cold-c)*(cold-c);
        res = sqrt(res);
        if(res<=tol){
            cout<<"itr: "<<i<<endl;
            cout<<"Convergence succeeded!\n";
            break;
        }
    }
    cout.precision(15);
    cout<<"log10(P)=a-c/(t+b)\n";
    cout<<"a="<<a<<", b="<<b<<", c="<<c<<endl;
    
    double yMean = 0;
    for(int i=0; i<n; i++){
        yMean += y[i];
    }
    yMean /= n;
    
    double SSTot = 0;
    for(int i=0; i<n; i++){
        SSTot += (y[i]-yMean)*(y[i]-yMean);
    }
    double SSRes = AntFitDev(a,b,c,x,y,n);
    double R2 = 1 - (SSRes/SSTot);
    cout<<"R2="<<R2<<endl;
    
    return 0;
}
