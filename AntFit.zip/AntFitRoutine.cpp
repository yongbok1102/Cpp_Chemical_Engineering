#include <cmath>

double AntFitFunc(double a, double b, double c, double x){
    return  a - c/(x+b);
}

double AntFitDev(double a, double b, double c, double x[], double y[], int n){
    double r;
    double sum = 0;
    
    for(int i=0; i<n; i++){
        r = log10(y[i]) - AntFitFunc(a,b,c,x[i]);
        sum += r*r;
    }
    return sum;
}
