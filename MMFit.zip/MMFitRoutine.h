#include <cmath>

double MMFitFunc(double a, double b, double x);

double MMFitDev(double a, double b, double x[], double y[], int n);
