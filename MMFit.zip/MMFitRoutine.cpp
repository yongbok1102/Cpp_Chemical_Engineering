#include <cmath>

double MMFitFunc(double a, double b, double x){
    return (a*x)/(b+x);
}

double MMFitDev(double a, double b, double x[], double y[], int n){
    double r;
    double sum = 0;
    
    for(int i=0; i<n; i++){
        r = y[i] - MMFitFunc(a,b,x[i]);
        sum += r*r;
    }
    return sum;
}
